<?php
declare(strict_types=1);

return [

    'debug' => false,
    'config_cache_enabled' => true,

];
