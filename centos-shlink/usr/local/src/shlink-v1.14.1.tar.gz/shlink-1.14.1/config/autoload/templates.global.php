<?php
declare(strict_types=1);

return [

    'templates' => [
        'extension' => 'phtml',
    ],

    'plates' => [
        'extensions' => [
            // extension service names or instances
        ],
    ],

];
