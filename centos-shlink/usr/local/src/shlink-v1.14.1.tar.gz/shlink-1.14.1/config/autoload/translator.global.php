<?php
declare(strict_types=1);

use Shlinkio\Shlink\Common;

return [

    'translator' => [
        'locale' => Common\env('DEFAULT_LOCALE', 'en'),
    ],

];
