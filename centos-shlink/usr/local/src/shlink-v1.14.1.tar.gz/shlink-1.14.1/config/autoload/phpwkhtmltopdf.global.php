<?php
declare(strict_types=1);

return [

    'phpwkhtmltopdf' => [
        'images' => [
            'binary' => 'bin/wkhtmltoimage',
            'type' => 'jpg',
        ],
    ],

];
