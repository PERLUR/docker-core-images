<?php
declare(strict_types=1);

return [

    'preview_generation' => [
        'files_location' => 'data/cache',
    ],

];
