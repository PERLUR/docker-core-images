<?php
declare(strict_types=1);

namespace Shlinkio\Shlink;

return [

    'delete_short_urls' => [
        'visits_threshold' => 15,
        'check_visits_threshold' => true,
    ],

];
