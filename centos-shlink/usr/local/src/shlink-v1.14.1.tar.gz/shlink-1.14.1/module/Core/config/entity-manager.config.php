<?php
declare(strict_types=1);

return [

    'entity_manager' => [
        'orm' => [
            'entities_paths' => [
                __DIR__ . '/../src/Entity',
            ],
        ],
    ],

];
