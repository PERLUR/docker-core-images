<?php
declare(strict_types=1);

return [

    'templates' => [
        'paths' => [
            'ShlinkCore' => __DIR__ . '/../templates',
        ],
    ],

];
