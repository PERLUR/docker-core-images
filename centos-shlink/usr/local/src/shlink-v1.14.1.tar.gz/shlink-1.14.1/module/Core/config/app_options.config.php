<?php
declare(strict_types=1);

return [

    'app_options' => [],

];
