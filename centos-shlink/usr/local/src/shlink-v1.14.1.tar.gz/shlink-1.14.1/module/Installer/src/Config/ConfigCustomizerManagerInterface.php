<?php
declare(strict_types=1);

namespace Shlinkio\Shlink\Installer\Config;

use Psr\Container\ContainerInterface;

interface ConfigCustomizerManagerInterface extends ContainerInterface
{
}
