<?php
declare(strict_types=1);

namespace Shlinkio\Shlink\Installer\Exception;

use RuntimeException;

class InvalidConfigOptionException extends RuntimeException implements ExceptionInterface
{
}
