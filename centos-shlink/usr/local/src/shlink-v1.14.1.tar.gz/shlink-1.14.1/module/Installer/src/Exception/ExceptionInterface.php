<?php
declare(strict_types=1);

namespace Shlinkio\Shlink\Installer\Exception;

use Throwable;

interface ExceptionInterface extends Throwable
{
}
