<?php
declare(strict_types=1);

use Shlinkio\Shlink\Common\Template\Extension\TranslatorExtension;

return [

    'plates' => [
        'extensions' => [
            TranslatorExtension::class,
        ],
    ],

];
