<?php
declare(strict_types=1);

namespace Shlinkio\Shlink\Common\Image;

use Zend\ServiceManager\ServiceLocatorInterface;

interface ImageBuilderInterface extends ServiceLocatorInterface
{
}
