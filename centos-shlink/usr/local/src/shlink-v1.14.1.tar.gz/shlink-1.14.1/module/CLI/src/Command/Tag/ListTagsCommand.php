<?php
declare(strict_types=1);

namespace Shlinkio\Shlink\CLI\Command\Tag;

use Shlinkio\Shlink\Core\Entity\Tag;
use Shlinkio\Shlink\Core\Service\Tag\TagServiceInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;
use Zend\I18n\Translator\TranslatorInterface;
use function Functional\map;

class ListTagsCommand extends Command
{
    public const NAME = 'tag:list';

    /**
     * @var TagServiceInterface
     */
    private $tagService;
    /**
     * @var TranslatorInterface
     */
    private $translator;

    public function __construct(TagServiceInterface $tagService, TranslatorInterface $translator)
    {
        $this->tagService = $tagService;
        $this->translator = $translator;
        parent::__construct();
    }

    protected function configure(): void
    {
        $this
            ->setName(self::NAME)
            ->setDescription($this->translator->translate('Lists existing tags.'));
    }

    protected function execute(InputInterface $input, OutputInterface $output): void
    {
        $io = new SymfonyStyle($input, $output);
        $io->table([$this->translator->translate('Name')], $this->getTagsRows());
    }

    private function getTagsRows(): array
    {
        $tags = $this->tagService->listTags();
        if (empty($tags)) {
            return [[$this->translator->translate('No tags yet')]];
        }

        return map($tags, function (Tag $tag) {
            return [(string) $tag];
        });
    }
}
